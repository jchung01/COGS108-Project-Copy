# FinalProjects-Fa20

A collection of student projects from COGS 108 in Fall 2020. 

All students whose work is included here gave their explicit consent for their project to be included in this collection

Note: Files with an `_S` at the end of the file name are projects that were particularly strong project and impressive to our instructional staff. This does _not_ mean they earned a perfect score, but it _does_ indicate a strong project that was some combination of: 1) interesting, 2) clearly written, 3) well-analyzed, and 4) well done overall. 


