# FinalProjects-Wi21

A collection of student projects from COGS 108 in Winter 2021

All students whose work is included here gave their explicit consent for their project to be included in this collection

