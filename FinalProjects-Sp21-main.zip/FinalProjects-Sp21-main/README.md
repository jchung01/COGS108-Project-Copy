# FinalProjects-Sp21

A collection of student projects from COGS 108 in Spring 2021.

All students whose work is included here gave their explicit consent for their project to be included in this collection.

Projects with an `_S` in the filename are projects that have been recognized as particularly strong by course instructional staff. (Note: this does not mean they got a perfect score, but staff found their project particularly interesting, well analyzed, and/or well communicated.)

